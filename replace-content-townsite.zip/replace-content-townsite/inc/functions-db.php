<?php
/**
 * Functions DATA
 *
 * 
 */

add_action( 'save_post', 'add_new_post_multisite', 10, 3 );

function add_new_post_multisite( $post_id, $post, $update ){
	
	global $wpdb;
	
	if ( ! $post = get_post( $post ) )
		return;
		
	if ( !is_main_site()) return;
	
	if ( wp_is_post_revision( $post_id )) return;		
	
	if ( 'product' != $post->post_type && 'page' != $post->post_type ) return;
	
	//wp_die( $post );
	
	$sites = get_sites( array('site__not_in'=> array(1),'number'=>null));	
	
	$output1 = array();
	$output2 = array();	
	
	if(!$update){
		foreach($sites as $site){
	
			$bl = DBPREFIX . $site->blog_id .'_posts';
			
			$wpdb->replace( $bl,
				array(	'ID' => $post_id,
						'post_author'   => $post->post_author,
						'post_date' => $post->post_date,
						'post_title'    => $post->post_title,
						'post_status'   => $post->post_status,
						'post_name'   => $post->post_name,
						'guid' => $post->guid,
						'post_type' => $post->post_type,
						'post_date_gmt' => $post->post_date_gmt,
						'post_modified' => $post->post_modified,
						'post_modified_gmt' => $post->post_modified_gmt,
				));	
		}		
	}
	else{
		
		
		
		if ( 'product' == $post->post_type ){
			$products_categorys = get_the_terms($post_id, 'product_cat');
			
			if ( !empty( $products_categorys ) && !is_wp_error( $products_categorys ) ) {		
				
				foreach ($products_categorys as $term1) {			
					$output1[] = $term1->term_id;			
				}		
			}
		
			$products_terms = get_the_terms($post_id, 'product_tag');
			
			if ( !empty( $products_terms ) && !is_wp_error( $products_terms ) ) {		
				
				foreach ($products_terms as $term2) {			
					$output2[] = $term2->term_id;			
				}		
			}	
		}
		
		//$permalink_structure = get_option( 'permalink_structure' );
		
		foreach($sites as $site){
	
			$bl = DBPREFIX . $site->blog_id .'_posts';
			$tax = DBPREFIX . $site->blog_id .'_term_relationships';
			$termtax = DBPREFIX . $site->blog_id .'_term_taxonomy';
			$postmeta = DBPREFIX . $site->blog_id .'_postmeta';
			$optionsmeta = DBPREFIX . $site->blog_id .'_options';
		
			/*$wpdb->update( $bl,
				array(	'post_author'   => $post->post_author,
						'post_date' => $post->post_date,
						'post_title'    => $post->post_title,
						'post_status'   => $post->post_status,
						'post_name'   => $post->post_name,
						'guid' => $post->guid,
						'post_type' => $post->post_type,
						'post_date_gmt' => $post->post_date_gmt,
						'post_modified' => $post->post_modified,
						'post_modified_gmt' => $post->post_modified_gmt,
						'post_parent' => $post->post_parent,
				),
				array( 'ID' => $post_id )
				);*/
				
			switch_to_blog($site->blog_id); 
				$p_rep = get_post( $post_id );
			restore_current_blog();
			
			if(!empty($p_rep)){
				$wpdb->update( $bl,
				array(	'post_author'   => $post->post_author,
						'post_date' => $post->post_date,
						'post_title'    => $post->post_title,
						'post_status'   => $post->post_status,
						'post_name'   => $post->post_name,
						'guid' => $post->guid,
						'post_type' => $post->post_type,
						'post_date_gmt' => $post->post_date_gmt,
						'post_modified' => $post->post_modified,
						'post_modified_gmt' => $post->post_modified_gmt,
						'post_parent' => $post->post_parent,
				),
				array( 'ID' => $post_id ));
			}
			else if( empty($p_rep) && 'product' == $post->post_type){
				$wpdb->replace( $bl,
				array(	'ID' => $post_id,
						'post_author'   => $post->post_author,
						'post_date' => $post->post_date,
						'post_title'    => $post->post_title,
						'post_status'   => $post->post_status,
						'post_name'   => $post->post_name,
						'guid' => $post->guid,
						'post_type' => $post->post_type,
						'post_date_gmt' => $post->post_date_gmt,
						'post_modified' => $post->post_modified,
						'post_modified_gmt' => $post->post_modified_gmt,
				));	
			}			
			
			if( 'page' == $post->post_type ){
				
				$template = get_post_meta( $post_id, '_wp_page_template', true );
				
				switch_to_blog($site->blog_id); 
					update_post_meta( $post_id, '_wp_page_template', $template );
					//update_option( 'permalink_structure', $permalink_structure );
				restore_current_blog();
				
			}
				
			if ( 'product' == $post->post_type ){
				
				$price = get_post_meta( $post_id, '_price', true );
				$sale_price = get_post_meta( $post_id, '_sale_price', true );
				$regular_price = get_post_meta( $post_id, '_regular_price', true );
              if($site->blog_id != 168):
				switch_to_blog($site->blog_id); 
					update_post_meta( $post_id, '_price', $price );
					update_post_meta( $post_id, '_sale_price', $sale_price );
					update_post_meta( $post_id, '_regular_price', $regular_price );
				restore_current_blog();
              endif;	
				if($output1){
					foreach($output1 as $out1){
						
						$term_count1 = get_term($out1)->count;
						
						$wpdb->replace($tax,
									array('object_id' => $post_id,
										'term_taxonomy_id' => $out1)
									
						);
						
						$wpdb->update($termtax,
								array('count' => $term_count1),
								array( 'term_id' => $out1 )
						);
					}
				}
				if($output2){
					foreach($output2 as $out2){
						
						$term_count2 = get_term($out2)->count;
						
						$wpdb->replace($tax,
									array('object_id' => $post_id,
										'term_taxonomy_id' => $out2)
									
						);
						
						$wpdb->update($termtax,
								array('count' => $term_count2),
								array( 'term_id' => $out2 )
						);
					}
				}
			}
			$wpdb->delete( $postmeta, array('meta_key'   => '_wc_review_count' ));
			$wpdb->delete( $postmeta, array('meta_key'   => '_wc_rating_count' ));
			$wpdb->delete( $postmeta, array('meta_key'   => '_wc_average_rating'));
			$wpdb->delete( $postmeta, array('meta_key'   => '_wc_average_rating'));
			$wpdb->delete( $optionsmeta, array('option_name'   => '_transient_wc_report_sales_by_date'));
			$wpdb->delete( $optionsmeta, array('option_name'   => '_site_transient_yith_promo_message'));
			$wpdb->query( "DELETE FROM $optionsmeta WHERE option_name LIKE '%_transient_feed%'" );
			$wpdb->query( "DELETE FROM $optionsmeta WHERE option_name LIKE '%_transient_dash%'" );
			$wpdb->query( "DELETE FROM $optionsmeta WHERE option_name LIKE '%_transient_timeout%'" );			
		}
	}
	clean_post_cache( $post_id );	
	
}


add_action( 'wp_trash_post', 'action_function_name_trash' );

function action_function_name_trash( $post_id ){
	global $wpdb;
	
	$post = get_post( $post_id );
	
	if ( !is_main_site()) return;
	
	if ( 'product' != $post->post_type && 'page' != $post->post_type ) return;
	
	$sites = get_sites( array('site__not_in'=> array(1),'number'=>null));
	
		foreach($sites as $site){
		
			$bl = DBPREFIX . $site->blog_id .'_posts';
			
			$wpdb->update( $bl,
				array( 'post_status' => 'trash' ),
				array( 'ID' => $post_id )
			);	
		}	
}


add_action( 'delete_post', 'action_function_name_delete' );

function action_function_name_delete( $postid ){
	
	global $wpdb;
	
	$post = get_post( $postid );
	
	if ( !is_main_site()) return;
	
	if ( 'product' != $post->post_type && 'page' != $post->post_type ) return;
	
	$sites = get_sites( array('site__not_in'=> array(1),'number'=>null));
	
	foreach($sites as $site){		
		
		$bl = DBPREFIX . $site->blog_id .'_posts';		
		$wpdb->delete( $bl, array( 'ID' => $postid ) );
		
		$tax = DBPREFIX . $site->blog_id .'_term_relationships';	
		$wpdb->delete( $tax, array( 'object_id' => $postid ) );		
		
	}
}

//Taxonomy

add_action( 'create_term', 'add_new_create_term', 10, 3 );
function add_new_create_term( $term_id, $tt_id, $taxonomy ){
	
	global $wpdb;
	
	if ( !is_main_site()) return;
	
	$term = get_term( $term_id, $taxonomy);
	
	$sites = get_sites( array('site__not_in'=> array(1),'number'=>null));
	
		foreach($sites as $site){
		
			$bdterm = DBPREFIX . $site->blog_id .'_terms';
			$bdtax = DBPREFIX . $site->blog_id .'_term_taxonomy';

				$wpdb->insert($bdterm,
						array('term_id' => $term_id,
							'name' =>  $term->name,
							'slug' =>  $term->slug,
						)
				
				);
				$wpdb->insert($bdtax,
						array('term_taxonomy_id' => $term_id,
							'term_id' => $term_id,
							'taxonomy' => $taxonomy,
							'description' => $term->description,
							'parent' => $term->parent							
						)
				
				);	
				
			
		}	
    
}


add_action( 'edited_term', 'add_action_update_term', 10, 3 );

function add_action_update_term( $term_id, $tt_id, $taxonomy ){
	global $wpdb;
	
	if ( !is_main_site()) return;
	
	$term = get_term( $term_id, $taxonomy);
	
	$sites = get_sites( array('site__not_in'=> array(1),'number'=>null));
	
		foreach($sites as $site){
		
			$bdterm = DBPREFIX . $site->blog_id .'_terms';
			$bdtax = DBPREFIX . $site->blog_id .'_term_taxonomy';

				$wpdb->replace($bdterm,
						array('term_id' => $term_id,
							'name' =>  $term->name,
							'slug' =>  $term->slug,
						)
				
				);
				$wpdb->replace($bdtax,
						array('term_taxonomy_id' => $term_id,
							'term_id' => $term_id,
							'taxonomy' => $taxonomy,
							'description' => $term->description,
							'parent' => $term->parent							
						)
				
				);	
				
			
		}
}

add_action( 'delete_term', 'add_action_delete_term', 10, 3 );

function add_action_delete_term( $term_id, $tt_id, $taxonomy ){
	global $wpdb;
	
	if ( !is_main_site()) return;
	
	$sites = get_sites( array('site__not_in'=> array(1),'number'=>null));
	
		foreach($sites as $site){
		
			$bdterm = DBPREFIX . $site->blog_id .'_terms';
			$bdtax = DBPREFIX . $site->blog_id .'_term_taxonomy';

				$wpdb->delete( $bdterm, array( 'term_id' => $term_id ) );
				$wpdb->delete( $bdtax, array( 'term_taxonomy_id' => $term_id ) );		
		}
}
				


										
										
										
										
										
										
										
										