<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

add_filter( 'woocommerce_loop_product_link', 'towns_filter_woo_permalink', 10, 2 );

function towns_filter_woo_permalink( $the_permalink, $product ){
	
	$the_permalink = add_towns_permalink($the_permalink);
	
	return $the_permalink;
}

add_filter( 'woocommerce_add_to_cart_form_action', 'towns_filter_woo_add_link' );
add_filter( 'woocommerce_get_cart_url', 'towns_filter_woo_add_link' ); 
add_filter( 'woocommerce_get_cart_page_permalink', 'towns_filter_woo_add_link' );
add_filter( 'woocommerce_get_shop_page_permalink', 'towns_filter_woo_add_link' );

function towns_filter_woo_add_link( $product_permalink ){
	
	$product_permalink = add_towns_permalink( $product_permalink );
	
	return $product_permalink;
}


function add_towns_permalink($permalink){
	global $town_slug, $blog_id;
	
	if(!empty($town_slug)){
		
		if( $blog_id != 1 ){
			
			$blog = get_blog_details( $blog_id );
			$path = untrailingslashit($blog->path);
			
			if (strpos($permalink, $blog->path) !== false) {
				
				$permalink = str_replace( get_home_url( 1, $path), get_home_url( 1 ), $permalink);
				
			}
		}
		
		if(false === strpos( $permalink , $town_slug.'/')){
			
			$permalink = str_replace( RPCNML_BLOG_HOME_URL, get_home_url(1,'/'.$town_slug), $permalink);
			
		}
		
				
	} 		

	return $permalink;
}

function update_option_wc_blog_replace($value, $old_value, $option, $serialize = false){
	global $wpdb;
	
	if($serialize == true) $value = maybe_serialize($value);
	
	$sites = get_sites( array('site__not_in'=> array(1), 'number'=>null));
	
	foreach($sites as $site){
		$optionstable = DBPREFIX . $site->blog_id .'_options';
		switch_to_blog($site->blog_id); 
			$op = get_option( $option );
		restore_current_blog();
		if($op){
			$wpdb->update($optionstable, array('option_value' => $value), array('option_name'=> $option));		
		}
		else{
			$wpdb->replace($optionstable, array('option_name'=> $option, 'option_value' => $value));
		}
	}
}
add_filter( 'pre_update_option_woocommerce_email_base_color', 'filter_function_name_woocommerce_email_base_color', 10, 3 );
function filter_function_name_woocommerce_email_base_color( $value, $old_value, $option ){
	update_option_wc_blog_replace( $value, $old_value, $option );
	return $value;
}
add_filter( 'pre_update_option_woocommerce_email_background_color', 'filter_function_name_woocommerce_email_background_color', 10, 3 );
function filter_function_name_woocommerce_email_background_color( $value, $old_value, $option ){
	update_option_wc_blog_replace( $value, $old_value, $option );
	return $value;
}

add_filter( 'pre_update_option_woocommerce_email_body_background_color', 'filter_function_name_woocommerce_email_body_background_color', 10, 3 );
function filter_function_name_woocommerce_email_body_background_color( $value, $old_value, $option ){
	update_option_wc_blog_replace( $value, $old_value, $option );
	return $value;
}
add_filter( 'pre_update_option_woocommerce_email_text_color', 'filter_function_name_woocommerce_email_text_color', 10, 3 );
function filter_function_name_woocommerce_email_text_color( $value, $old_value, $option ){
	update_option_wc_blog_replace( $value, $old_value, $option );
	return $value;
}

add_filter( 'pre_update_option_woocommerce_email_footer_text', 'filter_function_name_woocommerce_email_footer_text', 10, 3 );
function filter_function_name_woocommerce_email_footer_text( $value, $old_value, $option ){
	update_option_wc_blog_replace( $value, $old_value, $option );
	return $value;
}

add_filter( 'pre_update_option_woocommerce_email_header_image', 'filter_function_name_woocommerce_email_header_image', 10, 3 );
function filter_function_name_woocommerce_email_header_image( $value, $old_value, $option ){
	update_option_wc_blog_replace( $value, $old_value, $option );
	return $value;
}

add_filter( 'pre_update_option_woocommerce_email_from_name', 'filter_function_name_woocommerce_email_from_name', 10, 3 );
function filter_function_name_woocommerce_email_from_name( $value, $old_value, $option ){
	update_option_wc_blog_replace( $value, $old_value, $option );
	return $value;
}

add_filter( 'pre_update_option_woocommerce_email_from_address', 'filter_function_name_woocommerce_email_from_address', 10, 3 );
function filter_function_name_woocommerce_email_from_address( $value, $old_value, $option ){
	update_option_wc_blog_replace( $value, $old_value, $option );
	return $value;
}
add_filter( 'pre_update_option_woocommerce_customer_processing_order_settings', 'filter_function_name_woocommerce_customer_processing_order_settings', 10, 3 );
function filter_function_name_woocommerce_customer_processing_order_settings( $value, $old_value, $option ){
	update_option_wc_blog_replace( $value, $old_value, $option, true );
	return $value;
}
add_filter( 'pre_update_option_woocommerce_new_order_settings', 'filter_function_name_woocommerce_new_order_settings', 10, 3 );
function filter_function_name_woocommerce_new_order_settings( $value, $old_value, $option ){
	update_option_wc_blog_replace( $value, $old_value, $option, true );
	return $value;
}
add_filter( 'pre_update_option_woocommerce_cancelled_order_settings', 'filter_function_name_woocommerce_cancelled_order_settings', 10, 3 );
function filter_function_name_woocommerce_cancelled_order_settings( $value, $old_value, $option ){
	update_option_wc_blog_replace( $value, $old_value, $option, true );
	return $value;
}
add_filter( 'pre_update_option_woocommerce_failed_order_settings', 'filter_function_name_woocommerce_failed_order_settings', 10, 3 );
function filter_function_name_woocommerce_failed_order_settings( $value, $old_value, $option ){
	update_option_wc_blog_replace( $value, $old_value, $option, true );
	return $value;
}
add_filter( 'pre_update_option_woocommerce_customer_on_hold_order_settings', 'filter_function_name_woocommerce_customer_on_hold_order_settings', 10, 3 );
function filter_function_name_woocommerce_customer_on_hold_order_settings( $value, $old_value, $option ){
	update_option_wc_blog_replace( $value, $old_value, $option, true );
	return $value;
}
add_filter( 'pre_update_option_woocommerce_customer_completed_order_settings', 'filter_function_name_woocommerce_customer_completed_order_settings', 10, 3 );
function filter_function_name_woocommerce_customer_completed_order_settings( $value, $old_value, $option ){
	update_option_wc_blog_replace( $value, $old_value, $option, true );
	return $value;
}
add_filter( 'pre_update_option_woocommerce_customer_refunded_order_settings', 'filter_function_name_woocommerce_customer_refunded_order_settings', 10, 3 );
function filter_function_name_woocommerce_customer_refunded_order_settings( $value, $old_value, $option ){
	update_option_wc_blog_replace( $value, $old_value, $option, true );
	return $value;
}
add_filter( 'pre_update_option_woocommerce_customer_invoice_settings', 'filter_function_name_woocommerce_customer_invoice_settings', 10, 3 );
function filter_function_name_woocommerce_customer_invoice_settings( $value, $old_value, $option ){
	update_option_wc_blog_replace( $value, $old_value, $option, true );
	return $value;
}
add_filter( 'pre_update_option_woocommerce_customer_note_settings', 'filter_function_name_woocommerce_customer_note_settings', 10, 3 );
function filter_function_name_woocommerce_customer_note_settings( $value, $old_value, $option ){
	update_option_wc_blog_replace( $value, $old_value, $option, true );
	return $value;
}
add_filter( 'pre_update_option_woocommerce_customer_reset_password_settings', 'filter_function_name_woocommerce_customer_reset_password_settings', 10, 3 );
function filter_function_name_woocommerce_customer_reset_password_settings( $value, $old_value, $option ){
	update_option_wc_blog_replace( $value, $old_value, $option, true );
	return $value;
}
add_filter( 'pre_update_option_woocommerce_customer_new_account_settings', 'filter_function_name_woocommerce_customer_new_account_settings', 10, 3 );
function filter_function_name_woocommerce_customer_new_account_settings( $value, $old_value, $option ){
	update_option_wc_blog_replace( $value, $old_value, $option, true );
	return $value;
}
add_filter( 'pre_update_option_woocommerce_bacs_settings', 'filter_function_name_woocommerce_bacs_settings', 10, 3 );
function filter_function_name_woocommerce_bacs_settings( $value, $old_value, $option ){
	update_option_wc_blog_replace( $value, $old_value, $option, true );
	return $value;
}
