<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly
}


add_filter( 'walker_nav_menu_start_el', 'replace_url_nav_menu', 10, 4 );
function replace_url_nav_menu( $item_output, $item, $depth, $args ){
	
	global $town_slug;
	$city = $town_slug;
	$os = array(17);
	if(!in_array($item->object_id, $os)){
		if(!empty($city)){
			$item_output = str_replace( RPCNML_BLOG_HOME_URL, get_home_url(1,'/'.$city), $item_output);
		}
	}	
	return $item_output;
}

add_filter( 'replace_link', 'filter_function_rep_src_link' );
add_filter( 'the_content', 'filter_function_rep_src_link' );
function filter_function_rep_src_link( $text ){
	
	if(is_admin()) return $text;
	
	global $town_slug;
	
	$text = str_replace( '%town%/', '', $text);	
	
	if(RPCNML_BLOG_ID == '1' && empty(TOWNS_ID)) return $text;
	
	
	
	if(!empty($town_slug) && RPCNML_BLOG_ID != 1 ){
		
		return str_replace( get_home_url( RPCNML_BLOG_ID ), get_home_url(1,'/'.$town_slug), $text);
		
		
	}
	
	if( RPCNML_BLOG_ID != 1 && empty($town_slug) ){
		
		//if(RPCNML_BLOG_ID == RPCNML_REPLECE_SITE) return $text;
		global $blog_id;
		
		$blog = get_blog_details( RPCNML_BLOG_ID );
		$path = untrailingslashit($blog->path);
		
		if (strpos($text, $blog->path) === false) {	
			return str_replace( get_home_url( 1 ), get_home_url( 1, $path), $text);			
		}
		else{
			return str_replace( RPCNML_BLOG_HOME_URL, get_home_url(1, $path), $text);
		}
	}
	
	$text = str_replace( RPCNML_BLOG_HOME_URL, get_home_url(1,'/'.$town_slug), $text);	
	
	return $text;
}

add_filter( 'the_permalink', 'filter_function_name_2524', 10, 2 );
function filter_function_name_2524( $text, $post ){
	
	if(is_admin()) return $text;
	
	global $town_slug;
	
	if(empty($town_slug)) return $text;

	$text = str_replace( RPCNML_BLOG_HOME_URL, get_home_url(1,'/'.$town_slug), $text);	
	$text = str_replace( '%town%/', '', $text);	
	
	
	return $text;
}



function add_multipages_title_seo( $text="" ){	
	
	if(RPCNML_BLOG_ID == '1' && empty(TOWNS_ID)) return $text;
	if(RPCNML_BLOG_ID == RPCNML_REPLECE_SITE ) return $text;
	
	global $wpdb, $town_name;
	
	$titles = get_option_multi('wpseo_titles', false, RPCNML_REPLECE_SITE );
	
	$post_id = get_the_ID();
	$meta_key = '_yoast_wpseo_title';
	$db = DBPREFIX . RPCNML_REPLECE_SITE . '_postmeta';
	
	
	if(is_front_page()){
		
		$text = $wpdb->get_var( $wpdb->prepare( "SELECT meta_value FROM $db WHERE meta_key = %s AND post_id = %d", $meta_key, 1 ) );			
	}
	elseif ( is_post_type_archive() ) {
		$post_type = get_query_var( 'post_type' );

		if ( is_array( $post_type ) ) {
			$post_type = reset( $post_type );
		}

		$text = $titles['title-ptarchive-' . $post_type];			
	}
	elseif ( is_archive() ) {
		
		$text = $titles['title-archive-wpseo'];
		
		if(empty($text) || strrpos($text, "%%") !== false){
			$object = get_queried_object();
			$taxmeta = get_option_multi('wpseo_taxonomy_meta', false, RPCNML_REPLECE_SITE );
			$text = $taxmeta[$object->taxonomy][$object->term_id]['wpseo_title'];
		}
	}
	else{
		$text = $wpdb->get_var( $wpdb->prepare( "SELECT meta_value FROM $db WHERE meta_key = %s AND post_id = %d", $meta_key, $post_id ) );	
		if(empty($text)){
			$text = get_the_title() .' - '. $town_name;
		}
	}
	
	return replace_content_text($text);	
}

function add_multipages_metadesc_seo( $text ){
	
	if(RPCNML_BLOG_ID == '1' && empty(TOWNS_ID)) return $text;
	if( RPCNML_BLOG_ID == RPCNML_REPLECE_SITE ) return $text;
	
	global $wpdb;
	
	$metadesc = get_option_multi('wpseo_titles', false, RPCNML_REPLECE_SITE );
	
	$db = DBPREFIX . RPCNML_REPLECE_SITE . '_postmeta';
	$meta_key = '_yoast_wpseo_metadesc';
	$post_id = get_the_ID();
	
	if(is_front_page()){		
		$text = $wpdb->get_var( $wpdb->prepare( "SELECT meta_value FROM $db WHERE meta_key = %s AND post_id = %d", $meta_key, 1 ) );		 
	}
	elseif ( is_post_type_archive() ) {
		$post_type = get_query_var( 'post_type' );

		if ( is_array( $post_type ) ) {
			$post_type = reset( $post_type );
		}

		$text = $metadesc['metadesc-ptarchive-' . $post_type];
		
	}
	elseif ( is_archive() ) {		
		$text = $metadesc['metadesc-archive-wpseo'];
		if(empty($text)){
			$object = get_queried_object();
			$taxmeta = get_option_multi('wpseo_taxonomy_meta', false, RPCNML_REPLECE_SITE );
			
			$text = $taxmeta[$object->taxonomy][$object->term_id]['wpseo_desc'];
		}
	}
	else{
				
		$text = $wpdb->get_var( $wpdb->prepare( "SELECT meta_value FROM $db WHERE meta_key = %s AND post_id = %d", $meta_key, $post_id ) );	
	}
	
	return replace_content_text($text);	
}

add_filter('wpseo_title', 'add_multipages_title_seo');
add_filter('wpseo_metadesc', 'add_multipages_metadesc_seo');



function head_pages_seo($text){	
	
	$t = pdz_get_option('pred'); // падеж из сайта в системе мультисайт
	
	if(RPCNML_BLOG_ID == 1 && empty(TOWNS_ID)){ return $text; }
	
	if(RPCNML_BLOG_ID == 1 && TOWNS_ID != null){
		
		$meta = get_term_meta( TOWNS_ID, 'twnc', true );		
		$value  = maybe_unserialize( $meta );
		if(!empty($value)){
			$t = $value['padegz']['pred']; // падеж из сайта в системе городов term
		}		
	}
	
	return $text.' в '.$t;	
}

add_filter('head_pages', 'head_pages_seo');