<?php

function sizes_multi( $img, $size, $icon = false ) {
	
	$width = '';
	$height = '';
	$src = RPCNML_HOME_URL_BLOG .'/wp-content/uploads/';
	
	if(empty($img['sizes'][$size])) $size = 'full';
	
		if($size == 'full'){
			$file = $img['file'];
			$width = $img['width'];
			$height = $img['height'];
		}
		else{
			$file_full = $img['file'];
			$file = $img['sizes'][$size]['file'];
			$width = $img['sizes'][$size]['width'];
			$height = $img['sizes'][$size]['height'];
			$ar_file = explode("/", $file_full);
			array_pop($ar_file);
			$file = implode("/", $ar_file).'/'.$file;
		}		
		$image = array($src.$file, $width, $height, $icon);	
	return $image;
}





function get_post_thumbnail_id_multi( $post = null ) {
	$post = get_post( $post );
	if ( ! $post ) {
		return '';
	}		
	return get_field_multi('_thumbnail_id', $post->ID);
}





function get_attachment_src_multi($attachment_id, $size = 'thumbnail', $icon = false){
	$ar = array();
	
	$col = get_field_multi_col($attachment_id);
		
	if ( is_array( $col ) ) {
		foreach($col as $cl){			
			$ar+= array($cl->meta_key => $cl->meta_value);			
		}
	}
	if(!empty($ar)){
		$img = maybe_unserialize($ar["_wp_attachment_metadata"]);
		$image = sizes_multi( $img, $size );
		return $image;
	}
}





function wp_get_attachment_image_src_multi( $image, $attachment_id, $size = 'thumbnail', $icon = false ){
	
	if( is_main_site()) return $image;	
	if(is_admin()) return $image;
	//var_dump($attachment_id);
	return get_attachment_src_multi($attachment_id, $size);
	
}
add_filter( 'wp_get_attachment_image_src', 'wp_get_attachment_image_src_multi', 10, 4 );




function wp_get_attachment_image_url_multi( $attachment_id, $size = 'thumbnail', $icon = false ) {
	$image = get_attachment_src_multi( $attachment_id, $size, $icon );
	
	return isset( $image['0'] ) ? $image['0'] : false;
}





function get_the_post_thumbnail_url_multi( $post = null, $size = 'post-thumbnail' ) {
	
	$post_thumbnail_id = get_post_thumbnail_id_multi( $post );
	
	if ( ! $post_thumbnail_id ) {
		return false;
	}
	return wp_get_attachment_image_url_multi( $post_thumbnail_id, $size );
}




function get_the_post_thumbnail_multi($html, $post_id, $post_thumbnail_id, $size, $attr){
	
	
	
	//$post = get_post( $post_id );
	
	//if ( 'products' != $post->post_type && 'page' != $post->post_type ) return $html;
		
	if (is_admin() || is_main_site()){
		return $html;
	}
	
	$tit = '';
	$ar = array();
	$img = array();
	$alt = '';
		
	if($size == 'post-thumbnail') $size = 'thumbnail';
	
	$post_thumbnail_id = get_post_thumbnail_id_multi( $post_id );

	$col = get_field_multi_col($post_thumbnail_id);
	$title = get_post_multisite($post_thumbnail_id);
	
	
	
	if ( is_object( $title ) ) {
		$tit = $title->post_title;
	}
	
	//$image_html = '';
	if ( is_array( $col ) ) {
		foreach($col as $cl){
			
			$ar+= array($cl->meta_key => $cl->meta_value);
			
		}
	}
	if(!empty($ar)){
		if(!empty($ar["_wp_attachment_metadata"])){
			$image = maybe_unserialize($ar["_wp_attachment_metadata"]);
			$img = sizes_multi( $image, $size );
		}
		if($img){
			list($src, $width, $height) = $img;
			$hwstring = image_hwstring($width, $height);
			
			if(!empty($ar["_wp_attachment_image_alt"])) $alt = $ar["_wp_attachment_image_alt"];
			
			$default_attr = array(
				'src'	=> $src,
				'class'	=> 'attachment-'.$size.' size-'.$size.' wp-post-'.$post_thumbnail_id,
				'alt'	=> trim( strip_tags( $alt ) ),
				'title'=>	$tit,
			);
			$attr = wp_parse_args( $attr, $default_attr );
			
			$attr = array_map( 'esc_attr', $attr );			
			$html = rtrim("<img $hwstring");
			foreach ( $attr as $name => $value ) {
				$html .= " $name=" . '"' . $value . '"';
			}
			$html .= ' />';		
		}
	}
	return $html;
}

add_filter('post_thumbnail_html', 'get_the_post_thumbnail_multi', 10, 5);





function the_post_thumbnail_url_multi( $size = 'post-thumbnail' ) {
	$url = get_the_post_thumbnail_url_multi( null, $size );
	if ( $url ) {
		echo esc_url( $url );
	}
}




function wp_get_attachment_image_multi($attachment_id, $size = 'thumbnail', $icon = false, $attr = ''){
	
	if(is_main_site()){
		return wp_get_attachment_image($attachment_id, $size, $icon, $attr);
	}
	
	$html = '';
	//$image = wp_get_attachment_image_src_multi($attachment_id, $size, $icon);
	//var_dump($image);
	$image = get_attachment_src_multi($attachment_id, $size);

	
	if ( $image ) {
		list($src, $width, $height) = $image;
		$hwstring = image_hwstring($width, $height);
		$size_class = $size;
		if ( is_array( $size_class ) ) {
			$size_class = join( 'x', $size_class );
		}
		
		$attachment = get_post_multisite($attachment_id);
		$default_attr = array(
			'src'	=> $src,
			'class'	=> "attachment-$size_class size-$size_class",
			'alt'	=> trim( strip_tags( get_field_multi( '_wp_attachment_image_alt', $attachment_id ) ) ),
		);

		$attr = wp_parse_args( $attr, $default_attr );
		
	
	$attr = apply_filters( 'wp_get_attachment_image_attributes', $attr, $attachment, $size );
		$attr = array_map( 'esc_attr', $attr );
		$html = rtrim("<img $hwstring");
		foreach ( $attr as $name => $value ) {
			$html .= " $name=" . '"' . $value . '"';
		}
		$html .= ' />';
	}

	return $html;
}


add_filter( 'wp_get_attachment_image_src', 'filter_function_str_rep_src', 10, 4 );
function filter_function_str_rep_src( $image, $attachment_id, $size, $icon ){
	
	if(is_admin()) return $image;
	if(RPCNML_BLOG_ID == '1') return $image;
	if(RPCNML_BLOG_ID == '11') return $image;
	
	$spb_details = get_blog_details(11)->path;
	$cur_details = get_blog_details()->path;
	$image[0] = str_replace($cur_details, '/', $image[0]);
	
	
	return $image;
}

