<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly
}

function get_repl_permalink_multi($post_id=null){	
	$permalink = get_permalink($post_id);	
	if(RPCNML_BLOG_ID == '1') return $permalink;	
	$permalink = str_replace(get_home_url(1), RPCNML_BLOG_HOME_URL, $permalink);	
	return $permalink;
}

function get_multi_permalink(){
	
	$permalink = get_permalink();
	
	if(RPCNML_BLOG_ID == '1') return $permalink;
	
	$permalink = str_replace(RPCNML_HOME_URL_BLOG, RPCNML_BLOG_HOME_URL, $permalink);
	
	return $permalink;
}

function get_multi_custom_uri($uri){
	
	if(RPCNML_BLOG_ID == '1') return $uri;

	$uri = str_replace(RPCNML_HOME_URL_BLOG, RPCNML_BLOG_HOME_URL, $uri);
	//$uri = str_replace(RPCNML_HOME_URL_HTTP_BLOG, RPCNML_BLOG_HOME_URL_HTTP, $uri);
	
	return $uri;
}

function the_get_multi_permalink(){	
	echo get_multi_permalink();
} 

	
/*								
add_filter( 'post_type_link', 'filter_function_post_type_link', 10, 3 );
function filter_function_post_type_link( $permalink, $post, $leavename ){	
	
	if(RPCNML_BLOG_ID == '1') return $permalink;	
	$permalink = str_replace(RPCNML_HOME_URL_BLOG, RPCNML_BLOG_HOME_URL, $permalink);
	
	return $permalink;
}
*/