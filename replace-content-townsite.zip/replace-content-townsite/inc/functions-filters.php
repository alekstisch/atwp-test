<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly
}


add_filter( 'walker_nav_menu_start_el', 'replace_url_nav_menu', 10, 4 );
function replace_url_nav_menu( $item_output, $item, $depth, $args ){
	
	global $town_slug;
	$city = $town_slug;
	$os = array(17);
	if(!in_array($item->object_id, $os)){
		if(!empty($city)){
			$item_output = str_replace( RPCNML_BLOG_HOME_URL, get_home_url(1,'/'.$city), $item_output);
		}
	}	
	return $item_output;
}

add_filter( 'replace_link', 'filter_function_rep_src_link' );
add_filter( 'the_content', 'filter_function_rep_src_link' );
function filter_function_rep_src_link( $text ){
	
	if(is_admin()) return $text;
	
	$text = str_replace( '%town%/', '', $text);	
	
	if(RPCNML_BLOG_ID == '1' && empty(TOWNS_ID)) return $text;
	
	$pr0 = '/(?<scheme>http[s]?):\/\/(?<domain>[\w\.-]+)(?<path>(\/\w+)*\/)?/i';
	$pr1 = '/(?<scheme>http[s]?):\/\/(?<domain>[\w\.-]+)(?<path>(\/\w+)*\/)?(?<html>(.*?)\.html?)?/i';
	
	$text = preg_replace_callback($pr1, function($rpurl){
		
		
		$url = $rpurl[0];
		$rep = array('http://','https://');
		//url текущего блога без http	
		$url = str_replace($rep,'',$url);
		
		//url текущего блога без http	
		$currdomname = str_replace($rep,'',RPCNML_BLOG_HOME_URL);
		//url текущего блога без http	
		$homedomname = str_replace($rep,'',RPCNML_HOME_URL_BLOG);	
		//url блога замены без http
		$repldomname = str_replace($rep,'',get_home_url( RPCNML_REPLECE_SITE ));
		
		global $town_slug, $blog_id;
		
		$replacepath = get_blog_details( RPCNML_REPLECE_SITE )->path;
		$currpath = get_blog_details( RPCNML_BLOG_ID )->path;

		$zzpath = untrailingslashit( $rpurl['path'] );
		
	
		// для сайтов системы мультисайт
		if( RPCNML_BLOG_ID != 1 && empty($town_slug) ){
			
			//if(RPCNML_BLOG_ID == RPCNML_REPLECE_SITE) return $text;
			//https://gepatit-stop-16-10-19.test/chisinau/pravila-i-usloviya.html
			// если в url нет path текущего блога
			// сюда подходит https://доменное имя/pravila-i-usloviya.html
			//return str_replace( $homedomname, $homedomname . $currpath, $text);
			if(empty($zzpath)){
				$url = str_replace( $homedomname, $homedomname . $currpath, $url);
			}
			else{
				// для категорий убедимся, что нет path
				if (strpos($rpurl['path'], $currpath) === false && strpos($rpurl['path'], $replacepath) === false) {
						
						$url = str_replace( $homedomname, $homedomname . $currpath, $url);	
									
				}
				else if (strpos($rpurl['path'], $replacepath) !== false && strpos($rpurl['path'], $currpath) === false) {
					
					$url = str_replace( $homedomname . $replacepath, $homedomname . $currpath, $url);
					
				}
			}			
			
		}
		// для городов но если контент подтягивается через свич с другого сайта 
		else if(!empty($town_slug) && RPCNML_BLOG_ID != 1 ){	
			
			if(empty($zzpath)){
				$url = str_replace( $homedomname, $homedomname . '/' . $town_slug. '/', $url);
			}
			else{
				if (strpos($rpurl['path'], $replacepath) === false) {
					
					$url = str_replace( $homedomname, $homedomname . '/' . $town_slug . '/', $url);
					
				}
				else{
					$url = str_replace( $currdomname, $homedomname . '/' . $town_slug.'/', $text);
				}				
				
			}			
		
		}
		
		// для городов но если контент подтягивается  с другого сайта 
		else if(!empty($town_slug) && RPCNML_BLOG_ID == 1 ){
				
			if(empty($zzpath)){
				$url = str_replace( $homedomname, $homedomname . '/' . $town_slug. '/', $url);
			}
			else{
				if (strpos($rpurl['path'], $replacepath) === false) {
					
					$url = str_replace( $homedomname, $homedomname . '/' . $town_slug . '/', $url);
					
				}
				else{
					$url = str_replace( $homedomname . $replacepath, $homedomname . '/' . $town_slug . '/', $url);
				}				
				
			}				
		
		}
		
		$url = str_replace('//','/',$url);
		return $rpurl['scheme'].'://'.$url;
	
	}, $text);		
	

	
	return $text;
}





//add_filter( 'replace_link', 'filter_function_rep_src_link' );
//add_filter( 'the_content', 'filter_function_rep_src_link_content' );
function filter_function_rep_src_link_content( $text ){
	
	if(is_admin()) return $text;
	
	$text = str_replace( '%town%/', '', $text);	
	
	if(RPCNML_BLOG_ID == '1' && empty(TOWNS_ID)) return $text;
	
	$pr0 = '/(?<scheme>http[s]?):\/\/(?<domain>[\w\.-]+)(?<path>(\/\w+)*\/)?/i';
	$pr1 = '/(?<scheme>http[s]?):\/\/(?<domain>[\w\.-]+)(?<path>(\/\w+)*\/)?(?<html>(.*?)\.html?)?/i';
	
	$text = preg_replace_callback($pr1, function($rpurl){
		
		
		$url = $rpurl[0];
		$rep = array('http://','https://');
		//url текущего блога без http	
		$url = str_replace($rep,'',$url);
		
		//url текущего блога без http	
		$currdomname = str_replace($rep,'',RPCNML_BLOG_HOME_URL);
		//url текущего блога без http	
		$homedomname = str_replace($rep,'',RPCNML_HOME_URL_BLOG);	
		//url блога замены без http
		$repldomname = str_replace($rep,'',get_home_url( RPCNML_REPLECE_SITE ));
		
		global $town_slug, $blog_id;
		
		$replacepath = get_blog_details( RPCNML_REPLECE_SITE )->path;
		$currpath = get_blog_details( RPCNML_BLOG_ID )->path;

		$zzpath = untrailingslashit( $rpurl['path'] );
		
	
		// для сайтов системы мультисайт
		if( RPCNML_BLOG_ID != 1 && empty($town_slug) ){
			
			//if(RPCNML_BLOG_ID == RPCNML_REPLECE_SITE) return $text;
			//https://gepatit-stop-16-10-19.test/chisinau/pravila-i-usloviya.html
			// если в url нет path текущего блога
			// сюда подходит https://доменное имя/pravila-i-usloviya.html
			//return str_replace( $homedomname, $homedomname . $currpath, $text);
			if(empty($zzpath)){
				//$url = str_replace( $homedomname, $homedomname . $currpath, $url);
			}
			else{
				// для категорий убедимся, что нет path
				if (strpos($rpurl['path'], $currpath) === false && strpos($rpurl['path'], $replacepath) === false) {
						
					//	$url = str_replace( $homedomname, $homedomname . $currpath, $url);	
									
				}
				else if (strpos($rpurl['path'], $replacepath) !== false && strpos($rpurl['path'], $currpath) === false) {
					
					$url = str_replace( $homedomname . $replacepath, $homedomname . $currpath, $url);
					
				}
			}			
			
		}
		// для городов но если контент подтягивается через свич с другого сайта 
		else if(!empty($town_slug) && RPCNML_BLOG_ID != 1 ){	
			
			if(empty($zzpath)){
				//$url = str_replace( $homedomname, $homedomname . '/' . $town_slug. '/', $url);
			}
			else{
				if (strpos($rpurl['path'], $replacepath) === false) {
					
				//	$url = str_replace( $homedomname, $homedomname . '/' . $town_slug . '/', $url);
					
				}
				else{
					$url = str_replace( $currdomname, $homedomname . '/' . $town_slug.'/', $text);
				}				
				
			}			
		
		}
		
		// для городов но если контент подтягивается  с главного сайта 
		else if(!empty($town_slug) && RPCNML_BLOG_ID == 1 ){
				
			if(empty($zzpath)){
				//$url = str_replace( $homedomname, $homedomname . '/' . $town_slug. '/', $url);
			}
			else{
				if (strpos($rpurl['path'], $replacepath) === false) {
					
					//$url = str_replace( $homedomname, $homedomname . '/' . $town_slug . '/', $url);
					
				}
				else{
					$url = str_replace( $homedomname . $replacepath, $homedomname . '/' . $town_slug . '/', $url);
				}				
				
			}				
		
		}
		
		$url = str_replace('//','/',$url);
		return $rpurl['scheme'].'://'.$url;
	
	}, $text);		
	

	
	return $text;
}














add_filter( 'the_permalink', 'filter_function_name_2524', 10, 2 );
function filter_function_name_2524( $text, $post ){
	
	if(is_admin()) return $text;
	
	global $town_slug;
	
	if(empty($town_slug)) return $text;

	$text = str_replace( RPCNML_BLOG_HOME_URL, get_home_url(1,'/'.$town_slug), $text);	
	$text = str_replace( '%town%/', '', $text);	
	
	
	return $text;
}



function add_multipages_title_seo( $text="" ){	
	
	if(RPCNML_BLOG_ID == '1' && empty(TOWNS_ID)) return $text;
	if(RPCNML_BLOG_ID == RPCNML_REPLECE_SITE ) return $text;
	
	global $wpdb, $town_name;
	
	$titles = get_option_multi('wpseo_titles', false, RPCNML_REPLECE_SITE );
	
	$post_id = get_the_ID();
	$meta_key = '_yoast_wpseo_title';
	$db = DBPREFIX . RPCNML_REPLECE_SITE . '_postmeta';
	
	
	if(is_front_page()){
		
		$text = $wpdb->get_var( $wpdb->prepare( "SELECT meta_value FROM $db WHERE meta_key = %s AND post_id = %d", $meta_key, 1 ) );			
	}
	elseif ( is_post_type_archive() ) {
		$post_type = get_query_var( 'post_type' );

		if ( is_array( $post_type ) ) {
			$post_type = reset( $post_type );
		}

		$text = $titles['title-ptarchive-' . $post_type];			
	}
	elseif ( is_archive() ) {
		
		$text = $titles['title-archive-wpseo'];
		
		if(empty($text) || strrpos($text, "%%") !== false){
			$object = get_queried_object();
			$taxmeta = get_option_multi('wpseo_taxonomy_meta', false, RPCNML_REPLECE_SITE );
			$text = $taxmeta[$object->taxonomy][$object->term_id]['wpseo_title'];
		}
	}
	else{
		$text = $wpdb->get_var( $wpdb->prepare( "SELECT meta_value FROM $db WHERE meta_key = %s AND post_id = %d", $meta_key, $post_id ) );		
	}
	if(empty($text)){
		return  apply_filters('head_pages', get_the_title());
	}
	return replace_content_text($text);	
}

function add_multipages_metadesc_seo( $text ){
	
	if(RPCNML_BLOG_ID == '1' && empty(TOWNS_ID)) return $text;
	if( RPCNML_BLOG_ID == RPCNML_REPLECE_SITE ) return $text;
	
	global $wpdb;
	
	$metadesc = get_option_multi('wpseo_titles', false, RPCNML_REPLECE_SITE );
	
	$db = DBPREFIX . RPCNML_REPLECE_SITE . '_postmeta';
	$meta_key = '_yoast_wpseo_metadesc';
	$post_id = get_the_ID();
	
	if(is_front_page()){		
		$text = $wpdb->get_var( $wpdb->prepare( "SELECT meta_value FROM $db WHERE meta_key = %s AND post_id = %d", $meta_key, 1 ) );		 
	}
	elseif ( is_post_type_archive() ) {
		$post_type = get_query_var( 'post_type' );

		if ( is_array( $post_type ) ) {
			$post_type = reset( $post_type );
		}

		$text = $metadesc['metadesc-ptarchive-' . $post_type];
		
	}
	elseif ( is_archive() ) {		
		$text = $metadesc['metadesc-archive-wpseo'];
		if(empty($text)){
			$object = get_queried_object();
			$taxmeta = get_option_multi('wpseo_taxonomy_meta', false, RPCNML_REPLECE_SITE );
			
			$text = $taxmeta[$object->taxonomy][$object->term_id]['wpseo_desc'];
		}
	}
	else{
				
		$text = $wpdb->get_var( $wpdb->prepare( "SELECT meta_value FROM $db WHERE meta_key = %s AND post_id = %d", $meta_key, $post_id ) );	
	}
	if(empty($text)){
		return  apply_filters('head_pages', get_the_title()) .' 	
&#9989; Лекарственные препараты для лечения ВГС ✭ Доступная цена! ✈ Быстрая доставка ➤ Индийские дженерики лучших производителей';
	}
	return replace_content_text($text);	
}

add_filter('wpseo_title', 'add_multipages_title_seo');
add_filter('wpseo_metadesc', 'add_multipages_metadesc_seo');



function head_pages_seo($text){	
	
	$t = pdz_get_option('pred'); // падеж из сайта в системе мультисайт
	
	if(RPCNML_BLOG_ID == 1 && empty(TOWNS_ID)){ return $text; }
	
	if(RPCNML_BLOG_ID == 1 && TOWNS_ID != null){
		
		$meta = get_term_meta( TOWNS_ID, 'twnc', true );		
		$value  = maybe_unserialize( $meta );
		if(!empty($value)){
			$t = $value['padegz']['pred']; // падеж из сайта в системе городов term
		}		
	}
	
	return $text.' в '.$t;	
}

add_filter('head_pages', 'head_pages_seo');




