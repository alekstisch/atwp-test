<?php

/**
* Склонение слов по падежам. С использованием api morpher.ru
* @var string $text - текст 
* @var integer $numForm - нужный падеж. Число от 0 до 5
*
* @return - вернет false при неудаче. При успехе вернет нужную форму слова
*/
function getNewFormText($text){
$urlXml = "https://ws3.morpher.ru/russian/declension?s=".urlencode($text);

$result = @simplexml_load_file($urlXml);

	if($result){
		$arrData = array();
		
		foreach ($result as $one) {
			$arrData[] = (string) $one;
		}
		return $arrData;
	}
	return false;
}

function pdz_get_option($option){
	$value = get_option('rpcnml');
	$value = $value['padegz'];
	return $value[$option];
}

add_action('wp','add_padegz_multisite');

function add_padegz_multisite(){
	$sitename = get_blog_details(RPCNML_BLOG_ID)->blogname;
	
	if( pdz_get_option('im') == ''){
		if(($text = getNewFormText($sitename)) !== false){	
			
			$padegz['padegz'] = array('im'=>$sitename, 'rod'=>$text[0],'dat'=>$text[1],'vin'=>$text[2].'[vin]','tvor'=>$text[3],'pred'=>$text[4]);
			maybe_serialize( wp_kses( $padegz ) );
			update_option( 'rpcnml', $padegz );	
		}	
	}
}

// падежи сайта замены
function pdz_all_get_option($option, $side_id){
	
	$value = get_option_multi('rpcnml',false, $side_id);
	if(!empty($value)){
		if(!empty($value[$option])){
			return $value[$option];
		}
	}	
	
	
}
// падежи активного сайта
function pdz_all_get_option_curr_site($option='', $side_id=null){
	
	if(RPCNML_BLOG_ID == 1 && TOWNS_ID != null){
		do_action( 'before_switch_blog1' );
			$meta = get_term_meta( TOWNS_ID, 'twnc', true );
		do_action( 'after_switch_blog1' );
		$value  = maybe_unserialize( $meta );
		if(!empty($value)){
			return $value[$option];
		}		
	}
	else{
		$value = get_option_multi('rpcnml',false, $side_id);
		if(!empty($value)){
			if(!empty($value[$option])){
				return $value[$option];
			}
		}
	}	
}


function replace_content_text($text){
	
	
	$padegh_site = pdz_all_get_option_curr_site('padegz', RPCNML_BLOG_ID );
	$padegh_gl_site = pdz_all_get_option('padegz', RPCNML_REPLECE_SITE);
		
	$text = str_replace($padegh_gl_site['vin'], $padegh_site['vin'], $text );
	$text = str_replace($padegh_gl_site['rod'], $padegh_site['rod'], $text );
	$text = str_replace($padegh_gl_site['pred'], $padegh_site['pred'], $text );
	$text = str_replace($padegh_gl_site['dat'], $padegh_site['dat'], $text );
	$text = str_replace($padegh_gl_site['tvor'], $padegh_site['tvor'], $text );	
	$text = str_replace($padegh_gl_site['im'], $padegh_site['im'], $text );
	
	
	return $text;
	
}

function replace_content_city_name($text){
	
	
	if(RPCNML_BLOG_ID == RPCNML_REPLECE_SITE) return str_replace('[vin]', '', $text );
	if(RPCNML_BLOG_ID == 1 && TOWNS_ID == null) return $text;
	
	$text = replace_content_text($text);
	
	return str_replace('[vin]', '', $text );
	
}

add_filter('the_content', 'replace_content_city_name');
add_filter('the_title', 'replace_content_city_name');
//add_filter('wpseo_title', 'replace_city_name');
//add_filter('wpseo_metadesc', 'replace_city_name');
add_filter('wp_list_pages', 'replace_city_name_spb');










