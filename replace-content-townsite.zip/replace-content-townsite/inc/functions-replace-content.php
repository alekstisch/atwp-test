<?php
/**
 * Functions DATA
 *
 * 
 */


function get_post_multisite( $post_id=null, $post_type = '', $side_id=null ) {
	
		global $wpdb;
		
		if($post_id == null) $post_id = get_the_ID();	
		
		if($side_id != null) $side = DBPREFIX . $side_id."_posts";
		else $side = DBPREFIX . "posts";
		
		$post_id = (int) $post_id;
		
		$_post = $wpdb->get_row( $wpdb->prepare( "SELECT * FROM $side WHERE ID = %d LIMIT 1", $post_id ) );
		
		if ( ! $_post )	return false;

		return  $_post ;
}
function get_post_multi( $post_id=null, $post_type = '', $side_id=null ){
	
	if(RPCNML_BLOG_ID == '1' && empty(TOWNS_ID)) return get_post_multisite( $post_id, $post_type );
	return get_post_multisite( $post_id, $post_type, $side_id );
}


function get_post_content_multisite($id = null, $post_type = '', $side_id=null){
	
	if($id == null){
		$post_content = get_the_content();
		if(!empty($post_content)) return $post_content;
	}
	
	if($post_type == '') $post_type = get_post_type( $id );
		
	$content = get_post_multisite($id, $post_type, $side_id);
	
	$content = $content->post_content;
	$content = str_replace( ']]>', ']]&gt;', $content );
	
	return $content;
	
}
function the_get_post_content_multisite($id = null, $post_type = '', $side_id=null){	
	echo apply_filters('the_content', get_post_content_multisite($id, $post_type, $side_id));	
}

function get_posts_multisite( $post_type = '', $side_id=null ){
	   
	global $wpdb;
		
	$sq = 'publish';
	
	if($post_type != '') $pt = $post_type;
	else $pt = 'post';
	
	if($side_id != null) $side = DBPREFIX . $side_id."_posts";
	else $side = DBPREFIX . "posts";
	
	$post = $wpdb->get_results( "SELECT * FROM $side WHERE post_type = '$pt' AND post_status = '$sq' ORDER BY post_date DESC");
	
	return $post; 
}

function get_terms_post_multisite( $term_id, $side_id=null ){
	   
	global $wpdb;	
		
	if($side_id != null) $side = DBPREFIX . $side_id."_term_relationships";
	else $side = DBPREFIX . "term_relationships";
	
	$posts = $wpdb->get_results( "SELECT * FROM $side WHERE term_taxonomy_id='$term_id'");	

	return $posts; 
}

function get_term_multi( $term, $taxonomy, $side_id ){
	   
	global $wpdb;	
		
	if($side_id != null) $side = DBPREFIX . $side_id."_term_taxonomy";
	else $side = DBPREFIX . "term_taxonomy";
	
	if($side_id != null) $tb = DBPREFIX . $side_id."_terms";
	else $tb = DBPREFIX . "terms";
	
	$result = $wpdb->get_row( $wpdb->prepare( "SELECT * FROM $tb AS t INNER JOIN $side as tt ON tt.term_id = t.term_id WHERE t.term_id = %d AND tt.taxonomy = %s", $term, $taxonomy ));
	
	return $result; 
}

function get_the_terms_multi( $post_id, $category, $side_id=null ){
	   
	global $wpdb;	
		
	if($side_id != null) $side = DBPREFIX . $side_id."_term_relationships";
	else $side = DBPREFIX . "term_relationships";
	
	$posts = $wpdb->get_results( "SELECT * FROM $side WHERE object_id='$post_id'");	

	return $posts; 
}


function get_option_multi( $option, $default = false, $side_id = null){
	
	if(RPCNML_BLOG_ID == '1' && TOWNS_ID == null) return get_option($option, $default);

	if($side_id != null) $side = DBPREFIX . $side_id."_options";
	else $side = DBPREFIX . "options";
	
	global $wpdb;

	$option = trim( $option );
	if ( empty( $option ) )
		return false;
	
	
	$row = $wpdb->get_row( $wpdb->prepare( "SELECT option_value FROM $side WHERE option_name = %s LIMIT 1", $option ) );
	
	
	if ( is_object( $row ) ) {
		$value = $row->option_value;
	}
	else{
		$value='';
	}
	return maybe_unserialize( $value );
}

function ot_get_option_multi($option,$default = false, $side_id = null){
	$value = get_option_multi('option_tree',$default, $side_id);
	return $value[$option];
}								

function get_theme_mod_multi($option, $default = false, $side_id=null){
	
	if(RPCNML_BLOG_ID == '1' && empty(TOWNS_ID)) return get_theme_mod($option, $default);	
		
	
	global $wpdb;
	
	if($side_id == 1) $side = DBPREFIX . "options";
	
	else $side = DBPREFIX . RPCNML_REPLECE_SITE . "_options";	
	
	
	$option = trim( $option );
	if ( empty( $option ) )
		return false;
	
	$theme_slug = get_option( 'stylesheet' );
	$theme_option = "theme_mods_$theme_slug";
	
	$row = $wpdb->get_row( $wpdb->prepare( "SELECT option_value FROM $side WHERE option_name = %s LIMIT 1", $theme_option ) );
	
		
	if ( is_object( $row ) ) {
		$value = $row->option_value;
	}
	else{
		$value='';
	}
	$value = maybe_unserialize( $value );
	
	return $value[$option];
}									
										
function get_field_multi($key, $post_id=false, $side_id=null){
	
	global $wpdb;
	
	if($post_id == false) $post_id = get_the_ID();	
	
	if(RPCNML_BLOG_ID == '1' && empty(TOWNS_ID) ) return get_post_meta( $post_id, $key, true);
	
	if($side_id != null) $side = DBPREFIX . $side_id."_postmeta";
	else $side = DBPREFIX . "postmeta";
	
		
	$row = $wpdb->get_row( $wpdb->prepare( "SELECT meta_value FROM $side WHERE meta_key = %s AND post_id = %d LIMIT 1", $key, $post_id ) );
	
	if ( is_object( $row ) ) {
		$value = $row->meta_value;
	}
	else{
		$value='';
	}
	
	return maybe_unserialize( $value );
}

function get_field_multi_row( $key, $post_id=false,$side_id=null){
	
	$col = get_field_multi_col( $post_id, $side_id );
	
	$ar = array();
	
	if ( is_array( $col ) ) {
		foreach($col as $cl){
			
			$pos = strpos( $cl->meta_key, $key);
			
			if ($pos !== false) {
				$ar[$cl->meta_key] = $cl->meta_value;
			}			
		}
	}
	
	return $ar;
}

function get_field_multi_col( $post_id=false, $side_id=null){
	
	global $wpdb;
	
	if($post_id == false) $post_id = get_the_ID();
	
	if($side_id != null) $side = DBPREFIX .$side_id."_postmeta";
	else $side = DBPREFIX . "postmeta";
	
	if(RPCNML_BLOG_ID == '1') $side = DBPREFIX . "postmeta";
	
	if($post_id == false) $post_id = get_the_ID();
		
	$post_id = (int) $post_id;
	
	$col = $wpdb->get_results( "SELECT meta_key, meta_value FROM $side WHERE  post_id = '$post_id'");
	
	if ( is_array( $col ) ) {
		return $col;
	}	
}

function allmetadata_multi($post_id=false, $side_id=null){
	
	$meta = get_field_multi_col( $post_id, $side_id);
	$ff = array();
	foreach( $meta as $mt ){
		$ff[$mt->meta_key] = maybe_unserialize($mt->meta_value);
	}
	return $ff;
}					




					
										
								
										
										
										
										
										
										