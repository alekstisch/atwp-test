<?php
/*
Plugin Name: Replace Content Townsite
Plugin URI: 
Description:
Author: Aleks Tisch
Version: 1.0
Author URI: 
*/
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}
define( 'RPCNML_PLUGIN_DIR', plugin_dir_path( __FILE__ ) );
define( 'RPCNML_PLUGIN_FILE', __FILE__ );



define ( 'RPCNML_BLOG_ID', get_current_blog_id() );//текущий блог id
define ( 'RPCNML_BLOG_HOME_URL', get_home_url( RPCNML_BLOG_ID ) );//url текущего блога
define ( 'RPCNML_HOME_URL_BLOG', get_home_url(1) );//url основного блога
define ( 'RPCNML_HOME_URL_HTTP_BLOG', get_home_url( 1, '', 'http' ) );//url основного блога протокол http
define ( 'RPCNML_BLOG_HOME_URL_HTTP', get_home_url( RPCNML_BLOG_ID, '', 'http' ) );//url текущего блога протокол http


function remove_table_prefix(){
	global $table_prefix;	
	if(RPCNML_BLOG_ID == '1') return $table_prefix;
	return str_replace(RPCNML_BLOG_ID .'_', '', $table_prefix);
}

define ( 'DBPREFIX', remove_table_prefix() );// префикс таблицы основного блога


function rpcnml_option($option){
	global $wpdb;
	
	$bd = DBPREFIX .'options';
	
	$option = trim( $option );
	if ( empty( $option ) )	return false;
	
	$row = $wpdb->get_row( $wpdb->prepare( "SELECT option_value FROM $bd WHERE option_name = %s LIMIT 1", $option ) );
	
	if ( is_object( $row ) ) $value = $row->option_value;
	else $value='';
	
	return maybe_unserialize( $value );
}
function rpcnml_option_rpcnml($option){
	$value = rpcnml_option('rpcnml');
	//var_dump($value);
	if(!empty($value)){
		return $value[$option];		
	}	
}
define ( 'RPCNML_REPLECE_SITE', rpcnml_option_rpcnml('site') ); // id сайта для замены

require RPCNML_PLUGIN_DIR . 'admin/functions.php';
require RPCNML_PLUGIN_DIR . 'inc/multisite-data.php';
require RPCNML_PLUGIN_DIR . 'inc/text.php';

require RPCNML_PLUGIN_DIR . 'inc/functions-db.php';
require RPCNML_PLUGIN_DIR . 'inc/functions-replace-content.php';
require RPCNML_PLUGIN_DIR . 'inc/functions-home-menu.php';
require RPCNML_PLUGIN_DIR . 'inc/functions-product.php'; 
require RPCNML_PLUGIN_DIR . 'inc/functions-img.php'; 
require RPCNML_PLUGIN_DIR . 'inc/functions-filters.php'; 
require RPCNML_PLUGIN_DIR . 'inc/woocommerce.php';



add_action( 'before_switch_main_site', 'action_function_main_nomine_site_before' );
function action_function_main_nomine_site_before(){
	
	if(RPCNML_BLOG_ID == '1' && empty(TOWNS_ID) ) return;
    return switch_to_blog(RPCNML_REPLECE_SITE); 
}

add_action( 'after_switch_main_site', 'action_function_main_nomine_site_after' );
function action_function_main_nomine_site_after(){
	if(RPCNML_BLOG_ID == '1' && empty(TOWNS_ID) ) return;
    return restore_current_blog(); 
}

add_action( 'before_switch_blog1', 'action_function_blog1_site_before' );
function action_function_blog1_site_before(){	
	return switch_to_blog(1);	
}

add_action( 'after_switch_blog1', 'action_function_blog1_site_after' );
function action_function_blog1_site_after(){
	 return restore_current_blog();
}

