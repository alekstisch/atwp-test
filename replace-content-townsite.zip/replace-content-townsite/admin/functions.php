<?php

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}


add_action('admin_menu', 'register_options_padegh_submenu_page');

function register_options_padegh_submenu_page() {
	add_submenu_page( 'options-general.php', 'Настройки плагина Replace Content Multisite', 'Replace Content Multisite', 'manage_options', 'padegh-submenu-page', 'options_padegh_submenu_page_callback' ); 
}

function options_padegh_submenu_page_callback() {
	padeghCallback('padegh');
}

function padeghCallback($page){?>
	<div class="wrap">
	<h1><span class="fa fa-pad fa-gear"></span>Настройки плагина Replace Content Multisite</h1>
	</div>
	<?php settings_errors(); ?>

	<form id="save-custom-textarea-form" method="post" action="options.php" class="textarea-general-form">
	<h2>Падежи</h2>
		<?php settings_fields( $page.'_editor-options' ); ?>
		<?php do_settings_sections( $page.'-submenu-page' ); ?>
		<?php submit_button(); ?>
	</form>
<?php
}
add_action( 'admin_init', 'padegh_padegh_settings' );

function padegh_padegh_settings() {
	
	
	//Custom CSS Options
	
	//master
	register_setting( 'padegh_editor-options', 'rpcnml', 'rpcnml_sanitize_callback' );
		
	add_settings_section( 'padegh_editor-section', '', '', 'padegh-submenu-page' );
	
	add_settings_field( 'rpcnml_im', 'Именительный', 'padegh_im_callback', 'padegh-submenu-page', 'padegh_editor-section' );
	add_settings_field( 'rpcnml_rod', 'Родительный', 'padegh_rod_callback', 'padegh-submenu-page', 'padegh_editor-section' );
	add_settings_field( 'rpcnml_dat', 'Дательный', 'padegh_dat_callback', 'padegh-submenu-page', 'padegh_editor-section' );
	add_settings_field( 'rpcnml_vin', 'Винительный', 'padegh_vin_callback', 'padegh-submenu-page', 'padegh_editor-section' );
	add_settings_field( 'rpcnml_tvor', 'Творительный', 'padegh_tvor_callback', 'padegh-submenu-page', 'padegh_editor-section' );
	add_settings_field( 'rpcnml_pred', 'Предложный', 'padegh_pred_callback', 'padegh-submenu-page', 'padegh_editor-section' );
	
	if(RPCNML_BLOG_ID == '1'):
		add_settings_field( 'rpcnml_site', 'Выбрать сайт для замены текста', 'padegh_site_callback', 'padegh-submenu-page', 'padegh_editor-section' );
	endif;
}


function padegh_im_callback(){
	$option = pdz_get_option('im');
	$option = $option ? $option : '';
	echo '<input name="rpcnml[padegz][im]" size="50%" value="'.$option.'" type="text">';
}

function padegh_rod_callback(){
	$option = pdz_get_option('rod');
	$option = $option ? $option : '';
	echo '<input name="rpcnml[padegz][rod]" size="50%" value="'.$option.'" type="text">';
}
function padegh_dat_callback(){
	$option = pdz_get_option('dat');
	$option = $option ? $option : '';
	echo '<input name="rpcnml[padegz][dat]" size="50%" value="'.$option.'" type="text">';
}
function padegh_vin_callback(){
	$option = pdz_get_option('vin');
	$option = $option ? $option : '';
	echo '<input name="rpcnml[padegz][vin]" size="50%" value="'.$option.'" type="text">';
}
function padegh_tvor_callback(){
	$option = pdz_get_option('tvor');
	$option = $option ? $option : '';
	echo '<input name="rpcnml[padegz][tvor]" size="50%" value="'.$option.'" type="text">';
}
function padegh_pred_callback(){
	$option = pdz_get_option('pred');
	$option = $option ? $option : '';
	echo '<input name="rpcnml[padegz][pred]" size="50%" value="'.$option.'" type="text">';
}
function padegh_site_callback(){	
	$sites = get_sites(array('number'=>null));
	echo '<select size="1" name="rpcnml[site]"><option disabled></option>';
		foreach($sites as $site){
			if ( RPCNML_REPLECE_SITE === $site->blog_id ) $sel = ' selected="selected"';
			else $sel  = '';
			echo '<option value="'. $site->blog_id .'"'.$sel.'>'. get_blog_details($site->blog_id)->blogname .'</option>';
		}				
	echo '</select>';	
}

function rpcnml_sanitize_callback( $options ){ 
	
	maybe_serialize( wp_kses( $options ) );
	
	return $options;
}